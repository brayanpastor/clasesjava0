
package sistema;

public class PROCESO {

    public static void main(String[] args) {
       paises p= new paises();
       p.setcodigo(1);
       p.setnombre("Peru");
       p.mostrar_pais();
        
    }
    
}
